# Data Folder

This folder contains datasets used by the dashboard.

- `mydata.csv`: Sample dashboard dataset.
- `anotherdata.json`: Example JSON data for dashboard.

Add more data files here as needed.